from flask import Flask, render_template
from flask_socketio import SocketIO, emit, disconnect
import threading
import time
import random
import numpy as np
from sklearn.ensemble import IsolationForest
from datetime import datetime

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

# Initialize SocketIO with proper settings
socketio = SocketIO(app, cors_allowed_origins="*", logger=True, engineio_logger=True, async_mode='threading')

class RealTimeEnergyMonitor:
    def __init__(self):
        self.anomaly_model = IsolationForest(contamination=0.005, random_state=42)
        self.data_history = []
        self.model_trained = False
        self.running = False
        self.connected_clients = 0
        
        self.appliances = {
            'overall_use': {'name': 'Overall Use', 'current': 1.5, 'baseline': 1.5},
            'fridge': {'name': 'Fridge', 'current': 0.3, 'baseline': 0.3},
            'dishwasher': {'name': 'Dishwasher', 'current': 0.0, 'baseline': 0.8},
            'microwave': {'name': 'Microwave', 'current': 0.01, 'baseline': 0.01}
        }
    
    def generate_realistic_data(self, appliance_id):
        """Generate realistic energy consumption data"""
        appliance = self.appliances[appliance_id]
        baseline = appliance['baseline']
        
        if appliance_id == 'overall_use':
            consumption = baseline + random.uniform(-0.3, 1.0)
            if random.random() < 0.05:
                consumption += random.uniform(1.5, 3.0)
        elif appliance_id == 'fridge':
            if random.random() < 0.1:
                consumption = baseline + random.uniform(0.2, 0.5)
            else:
                consumption = baseline + random.uniform(-0.1, 0.1)
        elif appliance_id == 'dishwasher':
            if random.random() < 0.15:
                consumption = baseline + random.uniform(-0.2, 0.6)
            else:
                consumption = random.uniform(0.0, 0.1)
        elif appliance_id == 'microwave':
            if random.random() < 0.08:
                consumption = random.uniform(1.2, 1.8)
            else:
                consumption = baseline + random.uniform(-0.005, 0.005)
        
        return max(0, consumption)
    
    def detect_anomaly(self, consumption_value):
        """Use your proven Isolation Forest approach"""
        if len(self.data_history) < 50:
            return False, 0.0
            
        if not self.model_trained:
            recent_data = np.array(self.data_history[-100:]).reshape(-1, 1)
            self.anomaly_model.fit(recent_data)
            self.model_trained = True
            print("✅ Anomaly detection model trained")
            
        prediction = self.anomaly_model.decision_function([[consumption_value]])
        is_anomaly = self.anomaly_model.predict([[consumption_value]])[0] == -1
        confidence = abs(prediction[0])
        
        return is_anomaly, confidence
    
    def stream_data(self):
        """FIXED: Properly indented continuous data streaming"""
        self.running = True
        time.sleep(3)  # Wait for server initialization
        print("🚀 Starting continuous data streaming...")
        
        counter = 0
        while self.running:
            counter += 1
            
            # Check for connected clients
            if self.connected_clients == 0:
                print("⏸️ No clients connected, waiting...")
                time.sleep(5)
                continue
                
            timestamp = datetime.now().strftime('%H:%M:%S')
            
            for appliance_id, appliance_info in self.appliances.items():
                consumption = self.generate_realistic_data(appliance_id)
                self.appliances[appliance_id]['current'] = consumption
                
                # Update history for anomaly detection
                self.data_history.append(consumption)
                if len(self.data_history) > 500:
                    self.data_history.pop(0)
                
                # Detect anomaly
                is_anomaly, confidence = self.detect_anomaly(consumption)
                
                # Prepare data for dashboard
                data_point = {
                'appliance_id': str(appliance_id),
                'appliance_name': str(appliance_info['name']),
                'timestamp': str(timestamp),
                'consumption': float(round(consumption, 3)),
                'is_anomaly': bool(is_anomaly),  # Convert numpy.bool_ to Python bool
                'confidence': float(round(confidence, 3))
}
                
                # Emit data to dashboard
                try:
                    socketio.emit('energy_update', data_point)
                    print(f"📡 Loop #{counter} - Sent: {appliance_info['name']} - {consumption:.3f} kW")
                except Exception as e:
                    print(f"❌ Error emitting energy update: {e}")
                
                # Emit anomaly alert if detected
                if is_anomaly:
                    alert_level = 'CRITICAL' if confidence > 0.5 else 'WARNING'
                    alert_data = {
                        'appliance_name': appliance_info['name'],
                        'timestamp': timestamp,
                        'consumption': consumption,
                        'alert_level': alert_level,
                        'confidence': confidence
                    }
                    
                    try:
                        socketio.emit('anomaly_alert', alert_data)
                        print(f"🚨 ANOMALY SENT: {appliance_info['name']} - {consumption:.3f} kW ({alert_level})")
                    except Exception as e:
                        print(f"❌ Error emitting anomaly alert: {e}")
            
            time.sleep(2)

# Initialize monitoring system
monitor = RealTimeEnergyMonitor()

# Flask routes
@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/test')
def test_page():
    """Test page to verify server"""
    return '''
    <h1>✅ Flask Server Test</h1>
    <script src="https://cdn.socket.io/4.7.4/socket.io.min.js"></script>
    <script>
        const socket = io();
        socket.on('connect', function() {
            console.log('✅ SocketIO Connected in test page!');
        });
    </script>
    '''

@app.route('/test-emit')
def test_emit():
    """Test route to manually trigger an emit"""
    socketio.emit('energy_update', {
        'appliance_id': 'overall_use',
        'appliance_name': 'Test Overall Use',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'consumption': 2.500,
        'is_anomaly': True,
        'confidence': 0.8
    })
    
    socketio.emit('anomaly_alert', {
        'appliance_name': 'Test Appliance',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'consumption': 2.500,
        'alert_level': 'WARNING',
        'confidence': 0.8
    })
    
    return "Test events emitted! Check your dashboard and browser console."

# SocketIO events
@socketio.on('connect')
def handle_connect():
    monitor.connected_clients += 1
    print(f'✅ Client connected! Total clients: {monitor.connected_clients}')
    
    # Send immediate welcome message
    emit('connection_status', {
        'status': 'connected', 
        'message': 'Dashboard connected successfully!',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'server_info': 'Smart Energy Monitoring System Active'
    })
    
    # Send test data immediately
    emit('energy_update', {
        'appliance_id': 'overall_use',
        'appliance_name': 'Overall Use',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'consumption': 1.234,
        'is_anomaly': False,
        'confidence': 0.0
    })
    
    print("📡 Welcome messages sent to new client")

@socketio.on('disconnect')
def handle_disconnect():
    monitor.connected_clients = max(0, monitor.connected_clients - 1)
    print(f'❌ Client disconnected! Total clients: {monitor.connected_clients}')

@socketio.on('test_message')
def handle_test_message(data):
    print(f"📨 Received test message: {data}")
    emit('test_response', {'message': 'Test successful!', 'received': data})

# Background data streaming
def start_data_stream():
    """Start background data streaming"""
    print("🔄 Starting data streaming thread...")
    monitor.stream_data()  # FIXED: Call the correct method name

# Main execution
if __name__ == '__main__':
    print("🚀 Starting Smart Energy Monitoring Dashboard...")
    print("📊 Dashboard will be available at:")
    print("   - Local: http://127.0.0.1:5001")
    print("   - Network: http://localhost:5001")
    print("🔧 Enhanced broadcasting and logging enabled")
    
    # Start data streaming in background thread
    streaming_thread = threading.Thread(target=start_data_stream, daemon=True)
    streaming_thread.start()
    
    # Start the Flask web server
    socketio.run(app, host='0.0.0.0', port=5001, debug=True, allow_unsafe_werkzeug=True)
